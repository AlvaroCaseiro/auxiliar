import * as i0 from '@angular/core';
import * as i1 from './streaming';
export declare const VgStreamingModuleNgFactory: i0.NgModuleFactory<i1.VgStreamingModule>;
