export interface IDRMLicenseServer {
    [index: string]: {
        serverURL: string;
    };
}
export declare class VgStreamingModule {
}
