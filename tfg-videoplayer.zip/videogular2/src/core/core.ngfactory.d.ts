import * as i0 from '@angular/core';
import * as i1 from './core';
export declare const VgCoreModuleNgFactory: i0.NgModuleFactory<i1.VgCoreModule>;
