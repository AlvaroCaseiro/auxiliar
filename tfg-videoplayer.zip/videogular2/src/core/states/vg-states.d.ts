export declare class VgStates {
    static VG_ENDED: string;
    static VG_PAUSED: string;
    static VG_PLAYING: string;
    static VG_LOADING: string;
}
