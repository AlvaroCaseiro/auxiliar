export declare class VgBufferingModule {
}
