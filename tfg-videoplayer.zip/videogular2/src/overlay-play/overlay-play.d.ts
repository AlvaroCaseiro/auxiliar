export declare class VgOverlayPlayModule {
}
