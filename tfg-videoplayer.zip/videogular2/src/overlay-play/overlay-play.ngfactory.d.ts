import * as i0 from '@angular/core';
import * as i1 from './overlay-play';
export declare const VgOverlayPlayModuleNgFactory: i0.NgModuleFactory<i1.VgOverlayPlayModule>;
