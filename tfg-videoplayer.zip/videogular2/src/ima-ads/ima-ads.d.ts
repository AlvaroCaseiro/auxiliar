export declare class VgImaAdsModule {
}
