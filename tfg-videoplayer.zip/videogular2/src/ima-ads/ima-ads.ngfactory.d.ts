import * as i0 from '@angular/core';
import * as i1 from './ima-ads';
export declare const VgImaAdsModuleNgFactory: i0.NgModuleFactory<i1.VgImaAdsModule>;
