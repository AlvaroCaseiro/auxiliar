export declare class VgControlsModule {
}
