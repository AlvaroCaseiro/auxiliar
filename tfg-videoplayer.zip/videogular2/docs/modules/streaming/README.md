## videogular2/streaming

Module to do streaming with HLS or DASH.

Import definition:

```typescript
...
import { VgStreamingModule } from 'videogular2/streaming';

@NgModule({
    ...
    imports: [
        ...
        VgStreamingModule
    ],
    ...
})
export class AppModule {
}
```
