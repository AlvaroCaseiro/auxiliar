# BitrateOption

Interface available on `videogular2/core` module.

## Properties

- **qualityIndex** :number;
- **width** :number;
- **height** :number;
- **bitrate** :number;
- **mediaType** :string;
- **label?** :string;
