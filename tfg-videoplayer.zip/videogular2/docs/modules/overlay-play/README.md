## videogular2/overlay-play

Module to display a big play button over the video.

Import definition:

```typescript
...
import { VgOverlayPlayModule } from 'videogular2/overlay-play';

@NgModule({
    ...
    imports: [
        ...
        VgOverlayPlayModule
    ],
    ...
})
export class AppModule {
}
```
